# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations


class Migration(migrations.Migration):

    operations = [
        migrations.RunPython(migrations.RunPython.noop)
    ]
